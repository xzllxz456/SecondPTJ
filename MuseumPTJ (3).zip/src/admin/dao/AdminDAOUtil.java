package admin.dao;

public class AdminDAOUtil {
}

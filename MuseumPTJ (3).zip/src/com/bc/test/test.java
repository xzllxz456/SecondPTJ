package com.bc.test;

import com.bc.model.dao.EduDetImpl;

public class test {
	public static void main(String[] args) {
//		EduDetImpl te = new EduDetImpl();
//		try {
//			te.exam();
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
	}
}

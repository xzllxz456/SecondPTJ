package com.bc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bc.command.CommandServlet;
import com.bc.command.UtilFunc;

@WebServlet("/exam")
public class exam extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String param = request.getParameter("aaa");
		CommandServlet Csl = null;
		if("aaa".equals(param)) {
			Csl = new UtilFunc();
		} else if("bbb".equals(param)) {
			Csl = new UtilFunc();
		}
		/*
		 * 파라미터값에 맞는 커맨드 처리
		 */
		String path = Csl.execute(request, response);
		request.getRequestDispatcher(path).forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}

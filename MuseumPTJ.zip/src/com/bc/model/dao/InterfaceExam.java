package com.bc.model.dao;

import java.util.List;


public interface InterfaceExam {
	/*
	 * 
	 *   db처리해주는 인터페이스
	 */
	//public static List<String> category() throws Exception;
	public List<String> exam() throws Exception;

	   
}

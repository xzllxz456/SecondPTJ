package com.bc.model.dao;

import java.util.List;

public class DAOExam implements InterfaceExam{

	@Override
	public List<String> exam() throws Exception {
		/* DB 주고받기
		 * SqlSession session = DBService.getFactory().openSession(); List<EmployeeVO>
		 * list = session.selectList("HR.list"); 
		 * session.close();
		 * 
		 * return list;
		 */
		return null;
	}
	
}

package com.bc.command;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bc.model.dao.DAOExam;

public class UtilFunc implements CommandServlet{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * 서블릿에서 reuquest response 매개변수로 받아와 기능처리
		 * 
		 */
		List<String> list;
		try {
			list= new DAOExam().exam();
			request.setAttribute("list", list);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return "이동할 주소.jsp";
	}
	
}
